import { useState, type FormEvent } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext';
import { roles, type UserRole } from '../../auth/types';
import { EmptyState, ErrorState, PageLoading } from '../../components/States';
import { InlineError, Pager, useCommand, useResource } from '../../components/Workflow';
import { formatDate } from '../../lib/workflows';
import { accountApi } from './api';

export function ProfilePage() {
  const auth = useAuth(); const navigate = useNavigate(); const state = useResource('profile', s => accountApi.me(s));
  const profile = useCommand(); const password = useCommand(); const [notice, setNotice] = useState('');
  async function save(e: FormEvent<HTMLFormElement>) { e.preventDefault(); const form = new FormData(e.currentTarget); await profile.run(async () => { const name = String(form.get('displayName') ?? '').trim(); if (name.length < 2 || name.length > 100) throw new Error('Họ tên cần từ 2 đến 100 ký tự.'); await accountApi.updateProfile(name); await auth.reloadUser(); setNotice('Đã cập nhật hồ sơ.'); state.reload(); }); }
  async function change(e: FormEvent<HTMLFormElement>) { e.preventDefault(); const form = new FormData(e.currentTarget); await password.run(async () => { const next = String(form.get('newPassword')); if (next !== form.get('confirmation')) throw new Error('Mật khẩu xác nhận chưa khớp.'); if (next.length < 12 || next.length > 128 || !/[A-Z]/.test(next) || !/[a-z]/.test(next) || !/[0-9]/.test(next) || !/[^A-Za-z0-9]/.test(next)) throw new Error('Mật khẩu mới cần 12–128 ký tự, chữ hoa, chữ thường, số và ký tự đặc biệt.'); await accountApi.changePassword(String(form.get('currentPassword')), next); await auth.logout(); navigate('/login', { replace: true, state: { message: 'Đã đổi mật khẩu và thu hồi phiên làm mới. Vui lòng đăng nhập lại.' } }); }); }
  if (state.loading) return <PageLoading />;
  if (state.error || !state.data) return <ErrorState message={state.error ?? 'Không tải được hồ sơ.'} retry={state.reload} />;
  return <section><div className="section-title"><div><p className="eyebrow">TÀI KHOẢN</p><h1>Hồ sơ cá nhân</h1></div></div>{notice && <p className="success-message" role="status">{notice}</p>}<div className="detail-grid"><form className="surface form-stack" onSubmit={e => void save(e)} key={state.data.updatedAt}><h2>Thông tin cá nhân</h2><p>{state.data.email}</p><p>Quyền: {state.data.roles.join(', ')}</p><label>Họ và tên<input name="displayName" defaultValue={state.data.displayName} required minLength={2} maxLength={100} autoComplete="name" /></label><p>Tham gia: {formatDate(state.data.createdAt)}</p><InlineError message={profile.error} /><button disabled={profile.busy || password.busy}>{profile.busy ? 'Đang lưu…' : 'Lưu hồ sơ'}</button></form><form className="surface form-stack" onSubmit={e => void change(e)}><h2>Đổi mật khẩu</h2><label>Mật khẩu hiện tại<input name="currentPassword" type="password" required maxLength={128} autoComplete="current-password" /></label><label>Mật khẩu mới<input name="newPassword" type="password" required minLength={12} maxLength={128} autoComplete="new-password" /></label><label>Xác nhận mật khẩu mới<input name="confirmation" type="password" required minLength={12} maxLength={128} autoComplete="new-password" /></label><p className="muted">Đổi mật khẩu sẽ thu hồi các phiên làm mới và yêu cầu đăng nhập lại. Token truy cập đã cấp ở dịch vụ khác có thể còn hiệu lực đến khi hết hạn, mặc định tối đa khoảng 10 phút.</p><InlineError message={password.error} /><button disabled={password.busy || profile.busy}>{password.busy ? 'Đang thay đổi…' : 'Đổi mật khẩu và đăng nhập lại'}</button></form></div></section>;
}

export function AdminUsersPage() {
  const [params, setParams] = useSearchParams(); const page = Math.max(1, Number(params.get('page')) || 1);
  const filters = { keyword: params.get('keyword') ?? '', role: params.get('role') ?? '', isActive: params.get('isActive') ?? '' };
  const state = useResource(`users:${params}`, signal => accountApi.list(page, signal, filters));
  function search(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const values = new FormData(e.currentTarget);
    setParams({ page: '1', keyword: String(values.get('keyword') ?? '').trim(), role: String(values.get('role') ?? ''), isActive: String(values.get('isActive') ?? '') });
  }
  return <section><div className="section-title"><div><p className="eyebrow">QUẢN TRỊ</p><h1>Quản lý tài khoản</h1></div><button onClick={state.reload} disabled={state.loading}>Tải lại</button></div>
    <form className="filters" role="search" onSubmit={search} key={JSON.stringify(filters)}>
      <label>Tìm tài khoản<input name="keyword" defaultValue={filters.keyword} maxLength={100} placeholder="Họ tên hoặc email" /></label>
      <label>Quyền<select name="role" defaultValue={filters.role}><option value="">Tất cả</option>{roles.map(role => <option key={role} value={role}>{role}</option>)}</select></label>
      <label>Hoạt động<select name="isActive" defaultValue={filters.isActive}><option value="">Tất cả</option><option value="true">Đang hoạt động</option><option value="false">Đã vô hiệu hóa</option></select></label>
      <button>Tìm kiếm</button><p>Tìm trên toàn bộ tài khoản. Kết quả và tổng số được phân trang từ máy chủ.</p>
    </form>
    {state.loading ? <PageLoading /> : state.error ? <ErrorState message={state.error} retry={state.reload} /> : <><div className="surface table-scroll"><table><thead><tr><th>Họ tên</th><th>Email</th><th>Quyền</th><th>Hoạt động</th></tr></thead><tbody>{state.data?.items.map(u => <tr key={u.id}><td><Link to={`/admin/users/${u.id}`}>{u.displayName}</Link></td><td>{u.email}</td><td>{u.roles.join(', ')}</td><td>{u.isActive ? 'Đang hoạt động' : 'Đã vô hiệu hóa'}</td></tr>)}</tbody></table>{!state.data?.items.length && <EmptyState message="Không có tài khoản phù hợp." />}</div>{state.data && <Pager page={page} total={state.data.total} pageSize={state.data.pageSize} onChange={p => setParams({ ...filters, page: String(p) })} />}</>}
  </section>;
}
export function AdminUserDetailPage() {
  const { id = '' } = useParams(); const auth = useAuth(); const navigate = useNavigate(); const state = useResource(`user:${id}`, s => accountApi.detail(id, s));
  const command = useCommand(); const [selectedRole, setSelectedRole] = useState<UserRole | ''>(''); const [confirmActive, setConfirmActive] = useState(false); const [notice, setNotice] = useState('');
  if (state.loading) return <PageLoading />;
  if (state.error || !state.data) return <ErrorState message={state.error ?? 'Không tìm thấy tài khoản.'} retry={state.reload} />;
  const user = state.data;
  async function changed(work: () => Promise<unknown>) { await command.run(async () => { await work(); setConfirmActive(false); setSelectedRole(''); if (auth.user?.id === id) { await auth.logout(); navigate('/login', { replace: true, state: { message: 'Tài khoản của bạn đã thay đổi. Vui lòng đăng nhập lại.' } }); } else { setNotice('Đã cập nhật tài khoản.'); state.reload(); } }); }
  return <section><Link to="/admin/users">← Quản lý tài khoản</Link><div className="detail-heading"><h1>{user.displayName}</h1><p>{user.email}</p></div>{notice && <p role="status" className="success-message">{notice}</p>}<InlineError message={command.error} /><div className="detail-grid"><article className="surface"><h2>Thông tin tài khoản</h2><dl className="metadata"><dt>Mã người dùng</dt><dd className="identifier">{user.id}</dd><dt>Trạng thái</dt><dd>{user.isActive ? 'Đang hoạt động' : 'Đã vô hiệu hóa'}</dd><dt>Ngày tạo</dt><dd>{formatDate(user.createdAt)}</dd><dt>Cập nhật</dt><dd>{formatDate(user.updatedAt)}</dd></dl><p>Đổi quyền hoặc vô hiệu hóa sẽ thu hồi phiên làm mới. Dịch vụ khác có thể chấp nhận token truy cập cũ đến khi hết hạn.</p><p>Hệ thống sẽ từ chối thao tác làm mất quản trị viên hoạt động cuối cùng.</p></article><article className="surface form-stack"><h2>Quyền và truy cập</h2><label>Quyền tài khoản<select value={selectedRole || user.roles[0]} onChange={e => setSelectedRole(e.target.value as UserRole)}>{roles.map(r => <option key={r} value={r}>{r}</option>)}</select></label><button disabled={command.busy || !selectedRole || user.roles.includes(selectedRole)} onClick={() => void changed(() => accountApi.role(id, selectedRole as UserRole))}>Lưu quyền</button>{confirmActive ? <div className="confirmation"><p>Xác nhận {user.isActive ? 'vô hiệu hóa' : 'kích hoạt'} tài khoản {user.email}?</p><button disabled={command.busy} onClick={() => void changed(() => accountApi.active(id, !user.isActive))}>Xác nhận thay đổi trạng thái</button><button className="button-quiet" disabled={command.busy} onClick={() => setConfirmActive(false)}>Quay lại</button></div> : <button className="button-quiet" disabled={command.busy} onClick={() => setConfirmActive(true)}>{user.isActive ? 'Vô hiệu hóa tài khoản' : 'Kích hoạt tài khoản'}</button>}</article></div></section>;
}
